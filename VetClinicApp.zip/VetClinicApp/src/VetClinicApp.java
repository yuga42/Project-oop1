// Author: Yugasai Enreddy
// Date: April 2025
// Description: Java Swing app for patient registration in a vet clinic with menu, validation, and file saving

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.*;

public class VetClinicApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(VetForm::new);
    }
}

class VetForm extends JFrame {
    private final JTextField patientField;
    private final JTextField ownerField;
    private final JTextField emailField;
    private final JRadioButton vet1, vet2, vet3;
    private final JLabel messageLabel;

    public VetForm() {
        setTitle("Vet Clinic - Patient Registration");
        setSize(450, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // Main panel
        JPanel panel = new JPanel(new GridLayout(13, 1, 10, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        Font labelFont = new Font("SansSerif", Font.BOLD, 14);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 14);

        // Patient Name
        JLabel patientLabel = new JLabel("Pets Name:");
        patientLabel.setFont(labelFont);
        patientField = new JTextField(20);
        patientField.setFont(fieldFont);

        // Owner Name
        JLabel ownerLabel = new JLabel("Owner's Name:");
        ownerLabel.setFont(labelFont);
        ownerField = new JTextField(20);
        ownerField.setFont(fieldFont);

        // Email
        JLabel emailLabel = new JLabel("Email Address:");
        emailLabel.setFont(labelFont);
        emailField = new JTextField(20);
        emailField.setFont(fieldFont);

        // Vet options
        JLabel vetLabel = new JLabel("Select a Veterinarian:");
        vetLabel.setFont(labelFont);

        vet1 = new JRadioButton("Dr.Reddy", true);
        vet2 = new JRadioButton("Dr.Smith");
        vet3 = new JRadioButton("Dr.Lopez");

        ButtonGroup vetGroup = new ButtonGroup();
        vetGroup.add(vet1);
        vetGroup.add(vet2);
        vetGroup.add(vet3);

        // Buttons
        JButton registerButton = new JButton("Register");
        registerButton.setMnemonic(KeyEvent.VK_R);
        registerButton.addActionListener(e -> registerPatient());

        JButton clearButton = new JButton("Clear");
        clearButton.setMnemonic(KeyEvent.VK_C);
        clearButton.addActionListener(e -> clearForm());

        JButton exitButton = new JButton("Exit");
        exitButton.setMnemonic(KeyEvent.VK_E);
        exitButton.addActionListener(e -> System.exit(0));

        // Message label
        messageLabel = new JLabel(" ");
        messageLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        messageLabel.setForeground(Color.RED);

        // Add components
        panel.add(patientLabel); panel.add(patientField);
        panel.add(ownerLabel); panel.add(ownerField);
        panel.add(emailLabel); panel.add(emailField);
        panel.add(vetLabel);
        panel.add(vet1); panel.add(vet2); panel.add(vet3);
        panel.add(registerButton); panel.add(clearButton); panel.add(exitButton);

        add(panel, BorderLayout.CENTER);
        add(messageLabel, BorderLayout.SOUTH);
        setVisible(true);
    }

    private void registerPatient() {
        messageLabel.setText(" ");

        String patient = patientField.getText().trim();
        String owner = ownerField.getText().trim();
        String email = emailField.getText().trim();

        if (patient.isEmpty()) {
            showMessage("Pet's name cannot be empty.");
            return;
        }
        if (owner.isEmpty()) {
            showMessage("Owner name cannot be empty.");
            return;
        }
        if (email.isEmpty() || !isValidEmail(email)) {
            showMessage("Invalid email address.");
            return;
        }

        String vet = vet1.isSelected() ? vet1.getText() : (vet2.isSelected() ? vet2.getText() : vet3.getText());
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("**Patient Registration Document**\n");
                writer.write("Patient: " + patient + "\n");
                writer.write("Owner: " + owner + "\n");
                writer.write("Email: " + email + "\n");
                writer.write("Vet: " + vet + "\n");
                writer.write("Date: " + date + "\n");
                showMessage("Patient registered successfully!");
            } catch (IOException ex) {
                showMessage("Error writing to file.");
            }
        }
    }

    private boolean isValidEmail(String email) {
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(email).matches();
    }

    private void clearForm() {
        patientField.setText("");
        ownerField.setText("");
        emailField.setText("");
        vet1.setSelected(true);
        messageLabel.setText(" ");
    }

    private void showMessage(String message) {
        messageLabel.setText(message);
    }
}
